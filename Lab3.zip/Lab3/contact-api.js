const express = require('express')
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express()
const port = 3000

let contacts = [{
    "Name": "Tony El Antoury",
    "Profession": "Author",
    "Tel_Number": "1234567",
    "Mobile_Number": "8901234",
   
},
{
    "Name": "Lara Croft",
    "Profession": "Archeologist",
    "Tel_Number": "1234567",
    "Mobile_Number": "20120701",
  
}];

app.use(cors());

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.post('/contact', (req, res) => {
    const contact = req.body;

    // output the book to the console for debugging
    console.log(contact);
    books.push(contact);

    res.send('Contact is added to the database');
});

app.get('/contact', (req, res) => {
    res.json(contacts);
});

app.get('/contact/:Mobile_Number', (req, res) => {

    const Mobile_Number = req.params.Mobile_Number;


    for (let contact of contacts) {
        if (contact.Mobile_Number === Mobile_Number) {
            res.json(contact);
            return;
        }
    }

    // sending 404 when not found something is a good practice
    res.status(404).send('Contact not found');
});

app.delete('/contact/:mobile_number', (req, res) => {
    console.log("calling delete api")
    const Mobile_Number = req.params.Mobile_Number;
    contacts = contacts.filter(i => {
        if (i.Mobile_Number !== Mobile_Number) {
            return true;
        }
        return false;
    });    console.log("after delete: " +  contacts)
    // sending 404 when not found something is a good practice
    res.send('Contact is deleted');
});

app.post('/contact/:Mobile_Number', (req, res) => {
    const Mobile_Number = req.params.Mobile_Number;
    const newContact = req.body;

    for (let i = 0; i < contacts.length; i++) {
        if (contacts[i].Mobile_Number === Mobile_Number) {
            contacts[i] = newContact;
        }
    }



});

app.listen(port, () => console.log(`Hello world app listening on port ${port}!`));