const setEditModal = (Mobile_Number) => {
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", `http://localhost:3000/contact/${Mobile_Number}`, false);
    xhttp.send();
    const contact = JSON.parse(xhttp.responseText);
    document.getElementById('name').value = contact["name"];
    document.getElementById('profession').value = contact["profession"];
    document.getElementById('Tel_Number').value = contact["Tel_Number"];
    document.getElementById('Mobile_Number').value = contact["Mobile_Number"];
    document.getElementById('editForm').action = `http://localhost:3000/contact/${contact["Mobile_Number"]}`;
}

const deleteContact = (Mobile_Number) => {
    console.log("calling deleteContact")
    const xhttp = new XMLHttpRequest();
    xhttp.open("DELETE", `http://localhost:3000/contact/${Mobile_Number}`, false);
    console.log("opened api")
    xhttp.send();
    alert("Contact deleted");
    location.reload();
}

const loadContacts = () => {
    const xhttp = new XMLHttpRequest();

    xhttp.open("GET", "http://localhost:3000/contact", false);
    xhttp.send();

    const contacts = JSON.parse(xhttp.responseText);

    for (let contact of contacts) {
        const x = `
            <div class="col-4 mt-2 mb-2" >
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">${contact.name}</h5>
                        <h6 class="card-subtitle mb-2 text-muted">${contact.profession}</h6>
                        <div>Telephone Number: ${contact.Tel_Number}</div>
                        <div>Mobile Number: ${contact.Mobile_Number}</div>
                        <hr>
                        <button type="button" class="btn btn-primary btn-block" onclick="setEditModal(${contact.Mobile_Number})" data-toggle="modal" data-target="#editContactModal">Edit</button>
                        <button type="button" class="btn btn-primary btn-block" onclick="deleteContact(${contact.Mobile_Number})" data-toggle="modal">Delete</button>
                    </div>
                </div>
            </div>
        `

        document.getElementById('contacts').innerHTML = document.getElementById('contacts').innerHTML + x;
    }
}

loadContacts();